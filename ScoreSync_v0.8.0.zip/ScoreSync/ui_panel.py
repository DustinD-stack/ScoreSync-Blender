import bpy
import time


class SCORESYNC_PT_main(bpy.types.Panel):
    bl_label = "ScoreSync"
    bl_idname = "SCORESYNC_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "ScoreSync"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # ── Setup Wizard ────────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Setup Wizard", icon='SETTINGS')

        # Step 1
        row = box.row()
        row.label(text="1. Install MIDI Dependencies")
        row.operator("scoresync.install_deps", icon='IMPORT', text="Install")

        # Step 2
        row = box.row()
        row.label(text="2. Refresh port lists")
        row.operator("scoresync.refresh_ports", icon='FILE_REFRESH', text="Refresh")

        # Step 3 — port selectors + validation
        box.label(text="3. Select MIDI ports:")
        box.prop(scene, "scoresync_input_port",  text="MIDI In  (F2B)")
        box.prop(scene, "scoresync_output_port", text="MIDI Out (B2F)")

        in_name  = getattr(scene, "scoresync_input_port",  "NONE") or "NONE"
        out_name = getattr(scene, "scoresync_output_port", "NONE") or "NONE"

        # Warn: same port selected for both
        if in_name != "NONE" and in_name == out_name:
            warn = box.box()
            warn.alert = True
            warn.label(text="In and Out are the same port!", icon='ERROR')

        # Warn: ports appear swapped (B2F as input, F2B as output)
        in_looks_b2f  = "B2F" in in_name.upper()  or "B2F" in in_name
        out_looks_f2b = "F2B" in out_name.upper() or "F2B" in out_name
        if in_looks_b2f or out_looks_f2b:
            warn = box.box()
            warn.alert = True
            warn.label(text="Ports may be swapped!", icon='ERROR')
            warn.label(text="In should be F2B, Out should be B2F")

        # Reminder: F2B must NOT be enabled as an FL input
        if in_name != "NONE" and "F2B" in in_name.upper():
            note = box.box()
            note.label(text="FL Studio reminder:", icon='INFO')
            note.label(text="Disable F2B as an FL MIDI Input")
            note.label(text="or FL will echo its own transport back.")

        # Hint: no ports found at all
        if in_name == "NONE" and out_name == "NONE":
            hint = box.box()
            hint.label(text="No MIDI ports found.", icon='INFO')
            hint.label(text="Create in loopMIDI:")
            hint.label(text="  ScoreSync_F2B")
            hint.label(text="  ScoreSync_B2F")

        # Step 4 — connect + FL script health
        row = box.row(align=True)
        row.label(text="4. Connect + check FL script:")
        row = box.row(align=True)
        row.operator("scoresync.connect",         icon='PLAY',     text="(Re)Connect")
        row.operator("scoresync.check_fl_script", icon='QUESTION', text="Check FL Script")

        ok = scene.scoresync_script_ok and (time.time() - scene.scoresync_script_ok_ts) < 10.0
        box.label(
            text=f"FL Script: {'OK' if ok else 'Not detected'}",
            icon='CHECKMARK' if ok else 'X',
        )

        # Step 5 — master mode pick
        box.label(text="5. Choose master mode:")
        box.prop(scene, "scoresync_master_mode", text="Master")
        master_status = getattr(scene, "scoresync_master_status", "")
        if master_status:
            box.label(text=f"Now: {master_status}", icon='DECORATE_ANIMATE')

        # ── Connection status ────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Connection", icon='LINKED')
        row = box.row(align=True)
        row.prop(scene, "scoresync_latency_ms")
        row.prop(scene, "scoresync_autoreconnect")
        status = getattr(scene, "scoresync_status", "Not connected")
        box.label(text=f"Status: {status}",
                  icon='CHECKMARK' if "Connected" in status else 'ERROR')
        row = box.row(align=True)
        row.label(text=f"LED: {scene.scoresync_led_text}")
        row.operator("scoresync.reconnect_now", icon='FILE_REFRESH', text="Reconnect now")

        # ── Transport-in (DAW → Blender) ─────────────────────────────────────
        box = layout.box()
        box.label(text="Transport-in (DAW → Blender)", icon='SEQUENCE')
        row = box.row(align=True)
        row.prop(scene, "scoresync_follow_clock")
        row.prop(scene, "scoresync_reset_on_start")
        row = box.row(align=True)
        row.prop(scene, "scoresync_use_manual_bpm")
        sub = row.row(align=True)
        sub.enabled = scene.scoresync_use_manual_bpm
        sub.prop(scene, "scoresync_manual_bpm", text="BPM")
        if not scene.scoresync_use_manual_bpm:
            box.label(text=f"Auto BPM: {scene.scoresync_bpm_estimate:.2f}")

        # ── Master / Duplex Assist ───────────────────────────────────────────
        box = layout.box()
        box.label(text="Master / Duplex Assist", icon='ARROW_LEFTRIGHT')
        row = box.row(align=True)
        row.prop(scene, "scoresync_master_mode", text="Master")
        master_status = getattr(scene, "scoresync_master_status", "")
        if master_status:
            box.label(text=master_status, icon='DECORATE_ANIMATE')
        box.prop(scene, "scoresync_master_hold_ms")

        box.separator(factor=0.5)
        box.label(text="Scrub send settings:")
        box.prop(scene, "scoresync_duplex_mode", text="Duplex")
        row = box.row(align=True)
        row.prop(scene, "scoresync_duplex_rate_hz")
        row.prop(scene, "scoresync_duplex_debounce_ms")
        row = box.row(align=True)
        row.prop(scene, "scoresync_duplex_use_mtc")
        row.prop(scene, "scoresync_duplex_mtc_fps", text="MTC FPS")

        mode = scene.scoresync_duplex_mode
        if mode == 'OFF':
            box.label(text="Duplex off — DAW drives Blender only")
        elif mode == 'ASSIST':
            box.label(text="Assist — scrub Blender nudges DAW when FL stopped")
        else:
            box.label(text="Force — always push (testing only)")

        # ── Musical Utilities ────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Musical Utilities", icon='MARKER')
        row = box.row(align=True)
        row.prop(scene, "scoresync_add_marker_every_bar")
        row.prop(scene, "scoresync_time_sig_n")

        # ── Markers ──────────────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Markers", icon='MARKER_HLT')
        row = box.row(align=True)
        row.prop(scene, "scoresync_marker_preset", text="")
        row.operator("scoresync.drop_preset_marker", icon='MARKER_HLT', text="Drop")
        row = box.row(align=True)
        row.operator("scoresync.jump_prev_marker", icon='TRIA_LEFT',  text="Prev")
        row.operator("scoresync.jump_next_marker", icon='TRIA_RIGHT', text="Next")
        box.operator("scoresync.rename_markers_bar_beat", icon='SORTSIZE',
                     text="Rename → Bar:Beat")

        # ── Transport (Blender → DAW) ─────────────────────────────────────────
        box = layout.box()
        box.label(text="Transport (Blender → DAW)", icon='PLAY')
        row = box.row(align=True)
        row.operator("scoresync.tx_play", icon='PLAY',  text="Play")
        row.operator("scoresync.tx_stop", icon='PAUSE', text="Stop")
        box.operator("scoresync.tx_locate_to_timeline", icon='TIME',
                     text="Locate to Current Frame")

        # ── Diagnostics ──────────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Diagnostics", icon='INFO')
        box.operator("scoresync.list_ports",  icon='VIEWZOOM',          text="List MIDI Ports")
        box.prop(scene, "scoresync_debug", text="Debug logging")
        box.operator("scoresync.send_test",   icon='OUTLINER_OB_LIGHT', text="Send Test Event")
        row = box.row(align=True)
        row.operator("scoresync.snapshot",    icon='TEXT',              text="Snapshot to Console")
        row.operator("scoresync.export_log",  icon='EXPORT',            text="Export Log")

        # ── Presets ───────────────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Presets", icon='PRESET')
        row = box.row(align=True)
        op = row.operator("scoresync.apply_preset", text="FL Follow")
        op.preset = "FL_FOLLOW"
        op = row.operator("scoresync.apply_preset", text="Assist")
        op.preset = "BLENDER_ASSIST"
        op = row.operator("scoresync.apply_preset", text="Auto Master")
        op.preset = "AUTO_MASTER"

        # ── Tools ────────────────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Tools", icon='CONSOLE')
        box.operator("scoresync.export_fl_script", icon='EXPORT',
                     text="Export FL Script")
        box.operator("scoresync.open_docs", icon='HELP', text="Open Docs")
