bl_info = {
    "name": "ScoreSync",
    "author": "Dustin Douglas",
    "version": (0, 8, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > ScoreSync",
    "description": "Sync Blender’s timeline to your DAW over MIDI (preview).",
    "category": "System",
}

import bpy
import time

# ---- Imports ---------------------------------------------------------------
from .ui_panel import SCORESYNC_PT_main

from .ops_connection import (
    items_midi_inputs,
    items_midi_outputs,
    SCORESYNC_OT_refresh_ports,
    SCORESYNC_OT_connect,
    SCORESYNC_OT_reconnect_now,  # v0.2.2
    scoresync_timer,             # optional: for explicit unregister
)

from .ops_diagnostics import (
    SCORESYNC_OT_list_ports,
    SCORESYNC_OT_send_test,
    SCORESYNC_OT_install_deps,
    SCORESYNC_OT_open_docs,
    SCORESYNC_OT_export_fl_script,
    SCORESYNC_OT_snapshot,
    SCORESYNC_OT_export_log,
    SCORESYNC_OT_apply_preset,
)

from .ops_transport import (
    SCORESYNC_OT_play,
    SCORESYNC_OT_stop,
    SCORESYNC_OT_locate_to_timeline,
)

from .ops_markers import (
    SCORESYNC_OT_drop_preset_marker,
    SCORESYNC_OT_jump_prev_marker,
    SCORESYNC_OT_jump_next_marker,
    SCORESYNC_OT_rename_markers_bar_beat,
)

from .ops_duplex import (  # v0.3.0
    SCORESYNC_OT_set_duplex_mode,
    scoresync_duplex_timer_register,
    scoresync_duplex_timer_unregister,
)
from .ops_health import SCORESYNC_OT_check_fl_script
from .prefs import ScoreSyncPreferences, get_prefs, get_last_ports



# ---- Properties ------------------------------------------------------------
def register_props():
    scene = bpy.types.Scene

    scene.scoresync_input_port = bpy.props.EnumProperty(
        name="MIDI In", description="DAW -> Blender", items=items_midi_inputs
    )
    scene.scoresync_output_port = bpy.props.EnumProperty(
        name="MIDI Out", description="Blender -> DAW", items=items_midi_outputs
    )

    scene.scoresync_status = bpy.props.StringProperty(
        name="Status", default="Not connected"
    )

    # QoL
    scene.scoresync_latency_ms = bpy.props.IntProperty(
        name="Latency (ms)", default=0, min=0, max=500,
        description="Delay handling of incoming transport to stabilize jitter"
    )
    scene.scoresync_autoreconnect = bpy.props.BoolProperty(
        name="Auto-reconnect", default=True,
        description="Try to re-open ports if they disappear"
    )
    scene.scoresync_follow_clock = bpy.props.BoolProperty(
        name="Follow MIDI Clock", default=True,
        description="When on, incoming MIDI Clock drives Blender’s frame"
    )
    scene.scoresync_reset_on_start = bpy.props.BoolProperty(
        name="Reset on Start", default=True,
        description="On MIDI Start, jump to frame 0 before playing"
    )

    # Musical utilities
    scene.scoresync_add_marker_every_bar = bpy.props.BoolProperty(
        name="Add marker every bar", default=False,
        description="Drop a Blender timeline marker at each bar boundary"
    )
    scene.scoresync_time_sig_n = bpy.props.IntProperty(
        name="Time Sig (beats/bar)", default=4, min=1, max=12
    )
    scene.scoresync_bpm_estimate = bpy.props.FloatProperty(
        name="BPM (est.)", default=0.0, precision=2
    )

    # Marker workflow (v0.2.1)
    scene.scoresync_marker_preset = bpy.props.EnumProperty(
        name="Marker Preset",
        items=[
            ("INTRO", "Intro", ""),
            ("VERSE", "Verse", ""),
            ("HOOK", "Hook/Chorus", ""),
            ("BRIDGE", "Bridge", ""),
            ("BREAK", "Break", ""),
            ("DROP", "Drop", ""),
            ("OUTRO", "Outro", ""),
        ],
        default="VERSE",
    )

    # Session LED (updated by timer)
    scene.scoresync_led_text = bpy.props.StringProperty(
        name="Sync LED", default="🔴 idle"
    )

    # Duplex Assist (v0.3.0)
    scene.scoresync_duplex_mode = bpy.props.EnumProperty(
        name="Duplex Mode",
        items=[
            ("OFF", "Off", "DAW → Blender only"),
            ("ASSIST", "Assist", "Blender can nudge DAW while you scrub or press buttons"),
            ("FORCE", "Force", "Always push (for testing)"),
        ],
        default="ASSIST",
    )
    scene.scoresync_duplex_rate_hz = bpy.props.IntProperty(
        name="Scrub send rate (Hz)", default=20, min=5, max=60,
        description="How often to send SPP bursts while scrubbing"
    )
    scene.scoresync_duplex_debounce_ms = bpy.props.IntProperty(
        name="Scrub debounce (ms)", default=140, min=40, max=500,
        description="After scrubbing stops, wait this long, then send final locate"
    )
    # v0.3.1 – MTC (optional while scrubbing)
    scene.scoresync_duplex_use_mtc = bpy.props.BoolProperty(
        name="Use MTC while scrubbing",
        default=False,
        description="When ON, send MTC Quarter-Frame bursts during scrubs (SPP is still used for final locate)"
    )
    scene.scoresync_duplex_mtc_fps = bpy.props.EnumProperty(
        name="MTC FPS",
        items=[
            ("24", "24 fps", ""),
            ("25", "25 fps", ""),
            ("30", "30 fps (non-drop)", ""),
        ],
        default="30",
        description="Timecode rate for MTC quarter-frame messages"
    )
    # FL script health
    scene.scoresync_script_ok = bpy.props.BoolProperty(name="FL Script OK", default=False)
    scene.scoresync_script_ok_ts = bpy.props.FloatProperty(name="FL Script OK TS", default=0.0)
    scene.scoresync_debug = bpy.props.BoolProperty(
        name="Debug",
        default=False,
        description="Print transport/clock debug to the System Console"
    )

    # Manual BPM override (v0.4.0)
    scene.scoresync_use_manual_bpm = bpy.props.BoolProperty(
        name="Manual BPM",
        default=False,
        description="Use the value below instead of the auto-detected BPM for SPP conversions",
    )
    scene.scoresync_manual_bpm = bpy.props.FloatProperty(
        name="BPM",
        default=120.0, min=20.0, max=999.0, precision=2,
        description="Manual BPM used for SPP ↔ frame conversion when Manual BPM is enabled",
    )

    # Auto master switching (v0.5.0)
    scene.scoresync_master_mode = bpy.props.EnumProperty(
        name="Master Mode",
        items=[
            ("AUTO",    "Auto",    "FL leads when playing; Blender leads when FL stopped and user scrubs"),
            ("FL",      "FL",      "FL Studio is always master — Blender only follows"),
            ("BLENDER", "Blender", "Blender is always master — pushes transport to FL"),
        ],
        default="AUTO",
        description="Which side controls transport",
    )
    scene.scoresync_master_hold_ms = bpy.props.IntProperty(
        name="Blender Hold (ms)",
        default=2000, min=200, max=10000,
        description="How long Blender keeps master after a scrub or button press, before FL can reclaim",
    )
    scene.scoresync_master_status = bpy.props.StringProperty(
        name="Master Status",
        default="FL (auto)",
    )



def unregister_props():
    scene = bpy.types.Scene
    for attr in (
        "scoresync_input_port",
        "scoresync_output_port",
        "scoresync_status",
        "scoresync_latency_ms",
        "scoresync_autoreconnect",
        "scoresync_follow_clock",
        "scoresync_reset_on_start",
        "scoresync_add_marker_every_bar",
        "scoresync_time_sig_n",
        "scoresync_bpm_estimate",
        "scoresync_marker_preset",
        "scoresync_led_text",
        "scoresync_duplex_mode",
        "scoresync_duplex_rate_hz",
        "scoresync_duplex_debounce_ms",
        "scoresync_duplex_use_mtc",
        "scoresync_duplex_mtc_fps",
        "scoresync_script_ok",
        "scoresync_script_ok_ts",
        "scoresync_debug",
        "scoresync_use_manual_bpm",
        "scoresync_manual_bpm",
        "scoresync_master_mode",
        "scoresync_master_hold_ms",
        "scoresync_master_status",


    ):
        if hasattr(scene, attr):
            delattr(scene, attr)

# ---- Auto-restore -----------------------------------------------------------
def _auto_restore_ports():
    """Called once after register() and on load_post to reconnect last ports."""
    try:
        p = get_prefs()
        if p is None or not p.auto_connect:
            return
        in_name, out_name = get_last_ports()
        if not in_name and not out_name:
            return
        scene = bpy.context.scene
        if scene is None:
            return
        # Only set the props if the port names are still available
        try:
            from .ops_connection import _get_mido
            mido = _get_mido()
            if mido is None:
                return
            available_in  = set(mido.get_input_names())
            available_out = set(mido.get_output_names())
        except Exception:
            return
        changed = False
        if in_name in available_in:
            scene.scoresync_input_port = in_name
            changed = True
        if out_name in available_out:
            scene.scoresync_output_port = out_name
            changed = True
        if changed:
            bpy.ops.scoresync.connect()
            print(f"[ScoreSync] Auto-restored ports: In={in_name!r}  Out={out_name!r}")
    except Exception as e:
        print(f"[ScoreSync] Auto-restore failed: {e}")


def _auto_restore_timer():
    """Deferred one-shot timer so bpy.context is valid at startup."""
    _auto_restore_ports()
    return None  # returning None unregisters the timer


@bpy.app.handlers.persistent
def _load_post_handler(filepath):
    """Re-run auto-restore every time a .blend file loads."""
    # Give the scene a tick to settle before trying to set EnumProperty values
    try:
        bpy.app.timers.register(_auto_restore_ports, first_interval=0.5)
    except Exception:
        pass


# ---- Registration table ----------------------------------------------------
classes = (
    ScoreSyncPreferences,
    SCORESYNC_PT_main,
    SCORESYNC_OT_refresh_ports,
    SCORESYNC_OT_connect,
    SCORESYNC_OT_list_ports,
    SCORESYNC_OT_send_test,
    SCORESYNC_OT_install_deps,
    SCORESYNC_OT_open_docs,
    SCORESYNC_OT_play,
    SCORESYNC_OT_stop,
    SCORESYNC_OT_locate_to_timeline,
    SCORESYNC_OT_drop_preset_marker,
    SCORESYNC_OT_jump_prev_marker,
    SCORESYNC_OT_jump_next_marker,
    SCORESYNC_OT_rename_markers_bar_beat,
    SCORESYNC_OT_reconnect_now,       # v0.2.2
    SCORESYNC_OT_set_duplex_mode,     # v0.3.0
    SCORESYNC_OT_check_fl_script,
    SCORESYNC_OT_export_fl_script,    # v0.3.2
    SCORESYNC_OT_snapshot,            # v0.6.0
    SCORESYNC_OT_export_log,          # v0.6.0
    SCORESYNC_OT_apply_preset,        # v0.7.0
)

# ---- Add-on entry points ---------------------------------------------------
def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    register_props()

    # Start duplex assist timer (v0.3.0)
    try:
        scoresync_duplex_timer_register()
    except Exception:
        pass

    # Auto-restore last ports after a short delay so bpy.context is ready (v0.7.0)
    try:
        bpy.app.timers.register(_auto_restore_timer, first_interval=1.0)
    except Exception:
        pass

    # Re-run auto-restore whenever a .blend file loads (v0.7.0)
    if _load_post_handler not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_load_post_handler)


def unregister():
    # Remove load_post handler
    if _load_post_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_load_post_handler)

    # Stop duplex assist timer FIRST (so callbacks don't run during teardown)
    try:
        scoresync_duplex_timer_unregister()
    except Exception:
        pass

    # Stop the core timer
    try:
        bpy.app.timers.unregister(scoresync_timer)
    except Exception:
        pass

    # Stop the one-shot restore timer if it hasn't fired yet
    try:
        bpy.app.timers.unregister(_auto_restore_timer)
    except Exception:
        pass

    unregister_props()

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
