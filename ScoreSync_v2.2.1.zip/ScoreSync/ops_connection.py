# ScoreSync - ops_connection.py
# MIDI I/O, listener thread, main-thread apply, LED, auto-reconnect, and FL script health.

import bpy
import collections
import threading, time

# ---- mido loader -----------------------------------------------------------
def _get_mido():
    try:
        import mido
        try:
            mido.set_backend("mido.backends.rtmidi")
        except Exception:
            pass
        return mido
    except Exception:
        return None

# ---- Enums for ports -------------------------------------------------------
def items_midi_inputs(self, context):
    mido = _get_mido()
    items = []
    try:
        names = mido.get_input_names() if mido else []
    except Exception:
        names = []

    if not names:
        items.append(("NONE", "<no MIDI inputs found>", "Install deps and refresh"))
    else:
        for n in names:
            items.append((n, n, f"MIDI input: {n}"))
    return items


def items_midi_outputs(self, context):
    mido = _get_mido()
    items = []
    try:
        names = mido.get_output_names() if mido else []
    except Exception:
        names = []

    if not names:
        items.append(("NONE", "<no MIDI outputs found>", "Install deps and refresh"))
    else:
        for n in names:
            items.append((n, n, f"MIDI output: {n}"))
    return items


# ---- Device state (LED, timers, bars, etc.) --------------------------------
class _ScoreSyncDevice:
    # port state
    in_port_name = None
    out_port_name = None
    in_port = None
    out_port = None
    listener_running = False
    timer_registered = False
    stop_requested = False

    # health listener (listen for FL ACK on a second port)
    health_in_port = None
    health_listener_running = False
    health_stop_requested = False
    health_port_name = None


    # timing/health for LED
    last_clock_ts = 0.0
    last_spp_ts = 0.0
    last_any_ts = 0.0

    # BPM estimate from MIDI clock
    bpm_ema = 0.0
    bpm_alpha = 0.5        # faster convergence (was 0.2)
    bpm_stable_count = 0   # ticks within 1 BPM of estimate
    last_stop_ts = 0.0     # for double-tap stop → reset

    # frame/bar state
    frame_origin = 0
    frame_accum_f = 0.0
    clock_total = 0
    clocks_in_bar = 0
    bar_index = 1
    # debug clock stats
    clock_dbg_ts = 0.0
    clock_dbg_count = 0
    # debug / jitter guards
    last_spp_pos = None
    last_spp_apply_ts = 0.0
    dbg_last_print = 0.0
    dbg_clock_count = 0
    dbg_clock_ts = 0.0

    # True while FL is playing (received start/continue, cleared on stop).
    # ops_duplex uses this to silence outgoing SPP while FL is master.
    fl_is_playing = False

    # Echo guard: ignore incoming transport/SPP until this timestamp.
    # Set by ops_transport after button-press sends (Play/Stop/Locate).
    tx_lock_until = 0.0

    # Timestamp of the last SPP message received FROM FL.
    last_fl_spp_ts = 0.0

    # Auto master: Blender holds master until this timestamp, then FL reclaims.
    # Set by _claim_blender_master(); 0.0 means FL is currently master.
    master_until_ts = 0.0

    # Diagnostics: ring buffer of recent events for log export.
    # Each entry is a dict: {ts, type, detail}
    event_log = []
    EVENT_LOG_MAX = 200


DEV = _ScoreSyncDevice()


def _log_event(event_type: str, detail: str = ""):
    """Append to the DEV ring buffer (thread-safe for reads on main thread only)."""
    entry = {"ts": time.time(), "type": event_type, "detail": detail}
    DEV.event_log.append(entry)
    if len(DEV.event_log) > DEV.EVENT_LOG_MAX:
        del DEV.event_log[:-DEV.EVENT_LOG_MAX]


def _claim_blender_master(scene):
    """Blender takes transport master for the configured hold duration."""
    hold_ms = max(200, int(getattr(scene, "scoresync_master_hold_ms", 2000)))
    DEV.master_until_ts = time.time() + hold_ms / 1000.0
    _log_event("TX master_claim", f"hold={hold_ms}ms")


def _blender_is_master() -> bool:
    """True while Blender hold is active (AUTO mode check only)."""
    return time.time() < DEV.master_until_ts


def _get_bpm(scene) -> float:
    """Return the best available BPM: manual override → scene estimate → EMA → 120."""
    if getattr(scene, "scoresync_use_manual_bpm", False):
        manual = float(getattr(scene, "scoresync_manual_bpm", 0.0) or 0.0)
        if manual > 0.0:
            return manual
    est = float(getattr(scene, "scoresync_bpm_estimate", 0.0) or 0.0)
    if est > 0.0:
        return est
    ema = float(getattr(DEV, "bpm_ema", 0.0) or 0.0)
    return ema if ema > 0.0 else 120.0



# ---- Queue + small helpers --------------------------------------------------
_message_queue = collections.deque()  # deque[(ts, msg_dict)] — O(1) popleft
_QLOCK = threading.Lock()
_LISTENER_GEN = 0

def _dbg(scene, text, min_dt=0.0):
    """Rate-limited console debug when scene.scoresync_debug is ON."""
    if not getattr(scene, "scoresync_debug", False):
        return
    now = time.time()
    if min_dt <= 0.0 or (now - DEV.dbg_last_print) >= min_dt:
        print(text)
        DEV.dbg_last_print = now


def _enqueue(msg):
    with _QLOCK:
        _message_queue.append((time.time(), msg))
        while len(_message_queue) > 512:   # cap backlog — drop oldest
            _message_queue.popleft()

def _toggle_playing(play_wanted: bool):
    try:
        scr = bpy.context.screen
        if not scr:
            return
        is_playing = scr.is_animation_playing
        if play_wanted and not is_playing:
            bpy.ops.screen.animation_play()
        elif (not play_wanted) and is_playing:
            bpy.ops.screen.animation_play()
    except Exception:
        pass  # poll() failure in timer context — not fatal

def _add_marker_if_needed(scene):
    if not getattr(scene, "scoresync_add_marker_every_bar", False):
        return
    beats_per_bar = max(1, int(getattr(scene, "scoresync_time_sig_n", 4)))
    clocks_per_bar = 24 * beats_per_bar
    if DEV.clocks_in_bar >= clocks_per_bar:
        f = int(scene.frame_current)
        name = f"Bar {DEV.bar_index:03d}"
        try:
            scene.timeline_markers.new(name=name, frame=f)
        except Exception:
            scene.timeline_markers.new(name=f"{name}*", frame=f)
        DEV.bar_index += 1
        DEV.clocks_in_bar -= clocks_per_bar

def _update_led(scene):
    now = time.time()
    # Fresh clock in last 0.6s -> green
    if DEV.last_clock_ts and (now - DEV.last_clock_ts) <= 0.6:
        scene.scoresync_led_text = "🟢 clock OK"
        return
    # No clock, but SPP in last 2s -> yellow
    if DEV.last_spp_ts and (now - DEV.last_spp_ts) <= 2.0:
        scene.scoresync_led_text = "🟡 SPP only"
        return
    # Otherwise red
    scene.scoresync_led_text = "🔴 idle"


def _ensure_ports(scene):
    """If Auto-reconnect is ON, try to reopen missing ports when they reappear."""
    global _scan_last_restart_ts

    if not getattr(scene, "scoresync_autoreconnect", True):
        return
    mido = _get_mido()
    if not mido:
        return

    # INPUT
    if DEV.in_port_name and (not DEV.listener_running) and (DEV.in_port is None) and (not DEV.stop_requested):
        try:
            inputs = set(mido.get_input_names())
        except Exception:
            inputs = set()
        if DEV.in_port_name in inputs:
            try:
                global _LISTENER_GEN
                _LISTENER_GEN += 1
                gen = _LISTENER_GEN
                t = threading.Thread(target=_listener_loop, args=(DEV.in_port_name, gen), daemon=True)
                t.start()
                scene.scoresync_status = f"Auto-reconnect In: {DEV.in_port_name}"
            except Exception:
                pass

    # SCAN THREADS — restart if all died and autoreconnect is on
    if (DEV.timer_registered
            and _LEARN_SCAN_GEN > 0
            and _scan_alive_count == 0
            and (time.time() - _scan_last_restart_ts) > _SCAN_RESTART_INTERVAL):
        _scan_last_restart_ts = time.time()
        print("[ScoreSync] All scan threads dead — auto-restarting controller scan")
        try:
            start_learn_scan()
        except Exception:
            pass

    # OUTPUT
    if DEV.out_port_name and (DEV.out_port is None):
        try:
            outputs = set(mido.get_output_names())
        except Exception:
            outputs = set()
        if DEV.out_port_name in outputs:
            try:
                DEV.out_port = mido.open_output(DEV.out_port_name)
                scene.scoresync_status = f"Auto-reconnect Out: {DEV.out_port_name}"
            except Exception:
                pass

# ---- Main-thread apply ------------------------------------------------------
def _apply_incoming(scene, ts, msg):
    """Run on Blender's main thread via timer."""
    # latency gate
    latency_s = int(getattr(scene, "scoresync_latency_ms", 0)) / 1000.0
    if time.time() - ts < latency_s:
        return False

    t = msg.get("type")
    if getattr(scene, "scoresync_debug", False) and t in ("start", "stop", "continue", "spp"):
        print(f"[ScoreSync APPLY] {t}  msg={msg}")

    # Master mode gating: block FL transport/SPP while Blender holds master.
    if t in ("start", "stop", "continue", "spp"):
        master_mode = getattr(scene, "scoresync_master_mode", "AUTO")
        if master_mode == "BLENDER":
            _dbg(scene, f"[ScoreSync APPLY] master=BLENDER — dropping incoming {t}")
            return True
        if master_mode == "AUTO" and _blender_is_master():
            if t in ("start", "stop"):
                # FL explicitly pressing transport — release Blender hold and let it through
                DEV.master_until_ts = 0.0
                _dbg(scene, f"[ScoreSync APPLY] FL {t} overrides Blender hold")
            else:
                _dbg(scene, f"[ScoreSync APPLY] master=BLENDER(hold) — dropping incoming {t}")
                return True

    # Echo guard: ignore incoming transport/SPP for 350 ms after a button-press send.
    if t in ("start", "stop", "continue", "spp"):
        if time.time() < DEV.tx_lock_until:
            _dbg(scene, f"[ScoreSync APPLY] tx_lock active — dropping {t}")
            return True


    # FL script health ACK (thread-safe set on main thread)
    
    if t == "health_ok":
        scene.scoresync_script_ok = True
        scene.scoresync_script_ok_ts = time.time()
        scene.scoresync_led_text = "🟢 DAW Script OK"
        scene.scoresync_status = "DAW Script: OK"
        _log_event("health_ok", "FL script ACK received")
        return True



    if t == "start":
        DEV.last_any_ts = time.time()
        DEV.fl_is_playing = True
        if getattr(scene, "scoresync_reset_on_start", True):
            scene.frame_current = 0
            DEV.frame_origin = 0
            DEV.frame_accum_f = 0.0
            DEV.clock_total = 0
            DEV.clocks_in_bar = 0
            DEV.bar_index = 1
        _toggle_playing(True)
        scene.scoresync_status = "Start"
        _log_event("RX start")
        return True

    if t == "continue":
        DEV.last_any_ts = time.time()
        DEV.fl_is_playing = True
        _toggle_playing(True)
        scene.scoresync_status = "Continue"
        _log_event("RX continue")
        return True

    if t == "stop":
        now = time.time()
        double_tap = (now - DEV.last_stop_ts) < 0.6   # two stops within 600 ms
        DEV.last_stop_ts = now
        DEV.last_any_ts  = now
        DEV.fl_is_playing = False
        _toggle_playing(False)
        if double_tap:
            # Double-tap stop → rewind to frame 0
            scene.frame_current = 0
            DEV.frame_origin   = 0
            DEV.frame_accum_f  = 0.0
            DEV.clock_total    = 0
            DEV.clocks_in_bar  = 0
            DEV.bar_index      = 1
            scene.scoresync_status = "Stop → Rewind"
            _log_event("RX stop double-tap rewind")
        else:
            scene.scoresync_status = "Stop"
            _log_event("RX stop")
        return True

    if t == "spp":
        DEV.last_any_ts = DEV.last_spp_ts = DEV.last_fl_spp_ts = time.time()
        spp_units = int(msg.get("position", 0))

        fps = float(scene.render.fps or 30) / float(scene.render.fps_base or 1.0)
        bpm = _get_bpm(scene)

        beats = float(spp_units) / 4.0
        seconds = beats * (60.0 / bpm)
        frame = int(seconds * fps)

        scene.frame_current = max(0, frame)
        DEV.frame_origin = int(scene.frame_current)
        DEV.frame_accum_f = 0.0
        DEV.clock_total = 0
        DEV.clocks_in_bar = 0
        DEV.bar_index = 1
        scene.scoresync_status = f"SPP -> frame {frame}"
        _log_event("RX spp", f"spp={spp_units} frame={frame} bpm={bpm:.1f}")
        return True



    if t == "clock":
        # Use the arrival timestamp from the listener thread for accurate BPM.
        # Falling back to time.time() only if the message predates the ts field.
        now = msg.get("ts") or time.time()
        wall = time.time()

        # Debug: print effective clock rate about once per second
        if getattr(scene, "scoresync_debug", False):
            if DEV.clock_dbg_ts <= 0.0:
                DEV.clock_dbg_ts = wall
                DEV.clock_dbg_count = 0
            DEV.clock_dbg_count += 1
            if (wall - DEV.clock_dbg_ts) >= 1.0:
                hz = DEV.clock_dbg_count / (wall - DEV.clock_dbg_ts)
                print(f"[ScoreSync CLOCK] ~{hz:.1f} msgs/sec  follow_clock={getattr(scene,'scoresync_follow_clock',True)}")
                DEV.clock_dbg_ts = wall
                DEV.clock_dbg_count = 0

        prev_ts = DEV.last_clock_ts
        DEV.last_any_ts = wall
        DEV.last_clock_ts = now   # store arrival ts for next dt

        if not getattr(scene, "scoresync_follow_clock", True):
            return True  # user disabled

        # BPM estimate from MIDI clock (24 ticks per quarter note → 60/24 = 2.5)
        if prev_ts > 0:
            dt = now - prev_ts
            if 0.005 < dt < 0.12:   # valid range: ~50–300 BPM
                inst_bpm = 2.5 / dt
                if DEV.bpm_ema <= 0.0:
                    DEV.bpm_ema = inst_bpm
                else:
                    DEV.bpm_ema = DEV.bpm_alpha * inst_bpm + (1 - DEV.bpm_alpha) * DEV.bpm_ema

                # Snap to nearest integer BPM when stable (within 0.5 BPM for 48+ ticks = 2 beats)
                nearest = round(DEV.bpm_ema)
                if abs(DEV.bpm_ema - nearest) < 0.5:
                    DEV.bpm_stable_count += 1
                    if DEV.bpm_stable_count >= 48:
                        DEV.bpm_ema = float(nearest)
                else:
                    DEV.bpm_stable_count = 0

                scene.scoresync_bpm_estimate = float(DEV.bpm_ema)

        bpm = DEV.bpm_ema if DEV.bpm_ema > 0 else 120.0
        fps = float(scene.render.fps or 30) / float(scene.render.fps_base or 1.0)
        frames_per_clock = (fps * 60.0) / (bpm * 24.0)
        DEV.frame_accum_f += frames_per_clock
        advance = int(DEV.frame_accum_f)
        if advance:
            DEV.frame_accum_f -= advance
            # -- IMPORTANT: accumulate
            DEV.frame_origin += advance
            scene.frame_current = max(0, DEV.frame_origin)
            # Tell duplex: FL clock moved this frame — don't claim Blender master
            DEV.last_fl_spp_ts = time.time()

        DEV.clock_total += 1
        DEV.clocks_in_bar += 1
        _add_marker_if_needed(scene)
        scene.scoresync_status = "Clock"
        return True

    # ---- MIDI Program Change → bank switch (v2.0) ----
    if t == "program_change":
        try:
            from .ops_sampler import ingest_pc_for_sampler
            ingest_pc_for_sampler(
                int(msg.get("channel", 0)),
                int(msg.get("program", 0)),
                scene,
            )
        except Exception:
            pass
        return True

    # ---- Visual Sampler + FX trigger (v2.0) ----
    if t == "note_on":
        ch       = int(msg.get("channel",  0))
        note     = int(msg.get("note",     0))
        velocity = int(msg.get("velocity", 0))
        if velocity > 0:
            try:
                from .ops_sampler import ingest_note_for_sampler, DEV_SAMPLER, load_cache
                if not DEV_SAMPLER.cache:
                    DEV_SAMPLER.cache = load_cache()
                ingest_note_for_sampler(ch, note, velocity, scene)
            except Exception:
                pass
            try:
                from .ops_fx import handle_note_on_fx
                handle_note_on_fx(ch, note, velocity, scene)
            except Exception:
                pass
        return True

    if t == "note_off":
        ch   = int(msg.get("channel", 0))
        note = int(msg.get("note",    0))
        try:
            from .ops_fx import handle_note_off_fx
            handle_note_off_fx(ch, note, scene)
        except Exception:
            pass
        return True

    if t == "error":
        scene.scoresync_status = f"Error: {msg.get('err','')}"

        return True

    return True

# ---- Viewport redraw --------------------------------------------------------
_REDRAW_AREA_TYPES = {'VIEW_3D', 'NODE_EDITOR', 'PROPERTIES', 'IMAGE_EDITOR', 'DOPESHEET_EDITOR'}

def _tag_all_areas():
    """
    Force a repaint on all relevant areas and their regions.

    Why tag regions too:
    - area.tag_redraw() only redraws the main WINDOW region of that area.
    - ScoreSync N-panel lives in the UI region (side panel) of VIEW_3D —
      it won't repaint from area.tag_redraw() alone.
    - The ScoreSync popup editor is a separate WINDOW-type area and needs
      its own screen areas iterated.

    Only called when an apply tick reports a change, so idle cost is zero.
    """
    try:
        wm = bpy.context.window_manager
        for window in wm.windows:
            for area in window.screen.areas:
                if area.type in _REDRAW_AREA_TYPES:
                    area.tag_redraw()
                    for region in area.regions:
                        region.tag_redraw()
                # Popup / floating dialogs appear as WINDOW-type areas —
                # tag everything inside them so the ScoreSync editor repaints.
                elif area.type == 'EMPTY':
                    for region in area.regions:
                        region.tag_redraw()
    except Exception:
        pass


# ---- Timer ------------------------------------------------------------------
def scoresync_timer():
    try:
        scene = bpy.context.scene
        if scene is None:
            return 0.2

        # Auto-retry ports (wrapped so a port error never kills the timer)
        try:
            _ensure_ports(scene)
        except Exception:
            pass

        # Flush stale messages (older than 5 s) so a backlog never blocks sync
        now = time.time()
        with _QLOCK:
            while _message_queue and (now - _message_queue[0][0]) > 5.0:
                _message_queue.popleft()

        # Drain queue (prioritize transport/SPP over clock)
        n = 0
        with _QLOCK:
            # If backlog grows, drop excess clock ticks (keep newest 64 clocks)
            if len(_message_queue) > 256:
                clocks_kept = 0
                new_q = []
                for item in reversed(_message_queue):  # newest → oldest
                    t = item[1].get("type")
                    if t == "clock":
                        if clocks_kept < 64:
                            new_q.append(item)
                            clocks_kept += 1
                    else:
                        new_q.append(item)
                new_q.reverse()  # restore oldest → newest order
                _message_queue.clear()
                _message_queue.extend(new_q)

            while _message_queue and n < 64:
                ts, msg = _message_queue[0]
                try:
                    result = _apply_incoming(scene, ts, msg)
                except Exception:
                    result = True   # discard broken message, keep timer alive
                if result:
                    _message_queue.popleft()
                else:
                    break
                n += 1

    except Exception:
        pass  # never let the timer die — Blender deregisters on any uncaught exception


    # ---- MIDI Mapping + FX + Sampler learn + Transport ticks (v2.0) ----
    _viewport_dirty = False
    try:
        from . import ops_mapping as _ops_mapping
        if _ops_mapping.apply_mappings_tick(scene):
            _viewport_dirty = True
    except Exception:
        pass

    try:
        from . import ops_fx as _ops_fx
        if _ops_fx.apply_fx_tick(scene):
            _viewport_dirty = True
    except Exception:
        pass

    try:
        from . import ops_sampler as _ops_sampler
        if _ops_sampler.apply_sampler_learn_tick(scene):
            _viewport_dirty = True
    except Exception:
        pass

    # Drain scan-loop note queue → fire sampler pads from USB controllers
    # (The main F2B listener enqueues note_on via _apply_incoming; scan-loop
    #  ports are not F2B-routed so they bypass that path — drain here instead.)
    if _scan_note_queue:
        try:
            from .ops_sampler import ingest_note_for_sampler, DEV_SAMPLER, load_cache
            if not DEV_SAMPLER.cache:
                DEV_SAMPLER.cache = load_cache()
            while _scan_note_queue:
                ch, note, vel = _scan_note_queue.popleft()
                ingest_note_for_sampler(ch, note, vel, scene)
            _viewport_dirty = True
        except Exception:
            _scan_note_queue.clear()

    try:
        from . import ops_transport as _ops_transport
        if _ops_transport.apply_transport_midi_tick(scene):
            _viewport_dirty = True
    except Exception:
        pass

    if _viewport_dirty:
        _tag_all_areas()

    # Update master status string for the UI
    try:
        master_mode = getattr(scene, "scoresync_master_mode", "AUTO")
        if master_mode == "FL":
            scene.scoresync_master_status = "DAW (locked)"
        elif master_mode == "BLENDER":
            scene.scoresync_master_status = "Blender (locked)"
        elif _blender_is_master():
            remaining = max(0.0, DEV.master_until_ts - time.time())
            scene.scoresync_master_status = f"Blender ({remaining:.1f}s)"
        elif DEV.fl_is_playing:
            scene.scoresync_master_status = "DAW (playing)"
        else:
            scene.scoresync_master_status = "DAW (idle)"
    except Exception:
        pass

    # Update LED (🟢/🟡/🔴)
    # keep FL Script OK visible for 10s after last ACK
    try:
        if scene.scoresync_script_ok and (time.time() - scene.scoresync_script_ok_ts) < 10.0:
            scene.scoresync_led_text = "🟢 DAW Script OK"
            return 0.10
    except Exception:
        pass

    _update_led(scene)
    return 0.10  # ~10 Hz

# ---- Listener thread --------------------------------------------------------
# Package name used for sys.modules lookups (avoids stale cached references
# after Blender addon reloads — see _learn_scan_loop for full explanation).
_PKG = __name__.rsplit(".", 1)[0]   # e.g. "ScoreSync"


def _listener_loop(port_name, gen):
    """Background MIDI input thread. DO NOT touch bpy data directly here."""
    mido = _get_mido()
    if not mido:
        _enqueue({"type":"error","err":"mido not available"})
        return

    import sys as _sys

    try:
        DEV.listener_running = True
        with mido.open_input(port_name) as inport:
            print("[ScoreSync] MIDI In opened:", port_name)

            DEV.in_port = inport
            for msg in inport:
                scene = bpy.context.scene  # safe-ish for reads; don't write bpy data here

                if msg.type in ("start", "stop", "continue", "songpos"):
                    _dbg(scene, f"[ScoreSync RX] {msg.type}   raw={msg}", 0.0)

                if msg.type == "clock":
                    # count clocks and print once per second
                    now = time.time()
                    if DEV.dbg_clock_ts <= 0.0:
                        DEV.dbg_clock_ts = now
                        DEV.dbg_clock_count = 0
                    DEV.dbg_clock_count += 1
                    if (now - DEV.dbg_clock_ts) >= 1.0:
                        hz = DEV.dbg_clock_count / (now - DEV.dbg_clock_ts)
                        _dbg(scene, f"[ScoreSync RX] clock rate ~{hz:.1f}/sec", 0.0)
                        DEV.dbg_clock_ts = now
                        DEV.dbg_clock_count = 0

                if DEV.stop_requested or gen != _LISTENER_GEN:
                    break

                # Fresh module lookup each message — always uses current module state
                # even after an addon reload that replaces module objects in sys.modules.
                _m_map  = _sys.modules.get(f"{_PKG}.ops_mapping")
                _m_fx   = _sys.modules.get(f"{_PKG}.ops_fx")
                _m_samp = _sys.modules.get(f"{_PKG}.ops_sampler")
                _m_tp   = _sys.modules.get(f"{_PKG}.ops_transport")

                # ---- FL script health echo (ACK) ----
                if msg.type == "control_change" and msg.control == 119 and msg.value == 100:
                    _enqueue({"type": "health_ok"})
                    continue  # done with this msg

                # debug (prints but does not consume)
                if msg.type == "control_change" and msg.control == 119:
                    print("[ScoreSync] IN CC:", msg.control, msg.value)

                # ---- MIDI Mapping Layer + FX Rack (v2.0) ----
                if msg.type == "control_change":
                    if _m_map:
                        try: _m_map.ingest_midi_for_mapping("CC", msg.channel, msg.control, msg.value)
                        except Exception: pass
                        try: _m_map.ingest_midi_for_bank_switch("CC", msg.channel, msg.control, msg.value)
                        except Exception: pass
                    if _m_fx:
                        try: _m_fx.capture_fx_learn("CC", msg.channel, msg.control)
                        except Exception: pass
                    if _m_tp:
                        try: _m_tp.transport_learn_capture("CC", msg.channel, msg.control, msg.value)
                        except Exception: pass

                elif msg.type == "note_on":
                    if _m_map:
                        try: _m_map.ingest_midi_for_mapping("NOTE_ON", msg.channel, msg.note, msg.velocity)
                        except Exception: pass
                        try: _m_map.ingest_midi_for_bank_switch("NOTE_ON", msg.channel, msg.note, msg.velocity)
                        except Exception: pass
                    if _m_fx:
                        try: _m_fx.capture_fx_learn("NOTE_ON", msg.channel, msg.note)
                        except Exception: pass
                    if _m_samp:
                        try: _m_samp.sampler_pad_learn_capture("NOTE_ON", msg.channel, msg.note, msg.velocity)
                        except Exception: pass
                    if _m_tp:
                        try: _m_tp.transport_learn_capture("NOTE_ON", msg.channel, msg.note, msg.velocity)
                        except Exception: pass
                    # Enqueue for sampler fire + FX (must run on main thread)
                    _enqueue({"type": "note_on", "channel": msg.channel,
                              "note": msg.note, "velocity": msg.velocity})

                elif msg.type == "note_off":
                    if _m_map:
                        try: _m_map.ingest_midi_for_mapping("NOTE_OFF", msg.channel, msg.note, msg.velocity)
                        except Exception: pass
                    _enqueue({"type": "note_off", "channel": msg.channel,
                              "note": msg.note})

                elif msg.type == "pitchwheel":
                    norm = int((msg.pitch + 8192) * 127 // 16383)
                    if _m_map:
                        try: _m_map.ingest_midi_for_mapping("PITCH_BEND", msg.channel, 0, norm)
                        except Exception: pass

                elif msg.type == "aftertouch":
                    if _m_map:
                        try: _m_map.ingest_midi_for_mapping("AFTERTOUCH", msg.channel, 0, msg.value)
                        except Exception: pass

                elif msg.type == "polytouch":
                    if _m_map:
                        try: _m_map.ingest_midi_for_mapping("POLY_AT", msg.channel, msg.note, msg.value)
                        except Exception: pass

                elif msg.type == "program_change":
                    if _m_map:
                        try: _m_map.ingest_midi_for_mapping("PROG_CHG", msg.channel, msg.program, msg.program)
                        except Exception: pass
                    _enqueue({"type": "program_change", "channel": msg.channel,
                              "program": msg.program})

                # Transport
                if msg.type in ("start", "stop", "continue"):
                    _enqueue({"type": msg.type})

                # Song Position Pointer (14-bit)
                elif msg.type == "songpos":
                    _enqueue({"type": "spp", "position": msg.pos})

                # MIDI clock — include arrival timestamp for accurate BPM estimation
                elif msg.type == "clock":
                    _enqueue({"type": "clock", "ts": time.time()})

                # ignore other messages
    except Exception as e:
        _enqueue({"type":"error","err":f"MIDI In open failed ({port_name}): {e}"})

    finally:
        DEV.listener_running = False
        DEV.in_port = None

def _health_listener_loop(port_name):
    #"""Listen only for FL ACK CC119=100 on a second MIDI input."""
    mido = _get_mido()
    if not mido:
        return
    try:
        DEV.health_listener_running = True
        with mido.open_input(port_name) as inport:
            DEV.health_in_port = inport
            print("[ScoreSync] Health In opened:", port_name)
            for msg in inport:
                if DEV.health_stop_requested:
                    break

                # FL script ACK
                if msg.type == "control_change" and msg.control == 119 and msg.value == 100:
                    _enqueue({"type": "health_ok"})
    except Exception as e:
        print("[ScoreSync] Health In failed:", e)
    finally:
        DEV.health_listener_running = False
        DEV.health_in_port = None


# ── Universal MIDI learn scanner ─────────────────────────────────────────────
# When learn mode is active we open a lightweight listener on every available
# MIDI input port (excluding the one already open as the main F2B listener) so
# the user can move ANY connected controller without having to route it through
# loopMIDI.  Threads are stopped as soon as learn captures an event.
#
# Generation counter pattern (same as _LISTENER_GEN for the main listener):
# Each call to start_learn_scan() bumps _LEARN_SCAN_GEN.  Threads receive
# their generation at start and exit when it no longer matches — without
# touching the stop event.  This avoids the race where stop_learn_scan()
# sets the event, start_learn_scan() clears it, but old threads haven't
# checked yet and continue holding WinMM exclusive-access ports.

_LEARN_SCAN_GEN   = 0
_learn_scan_threads: list = []

# Thread-safe queue for note-on events from the universal scan loop.
# The learn scan loop runs on USB ports that the main F2B listener doesn't own.
# To fire sampler pads from those ports we can't call bpy directly from the
# thread, so we queue (channel, note, velocity) here and drain on the main
# thread inside scoresync_timer.
_scan_note_queue: collections.deque = collections.deque()

# ---- Scan health tracking ---------------------------------------------------
# _scan_alive_count: incremented when a scan thread opens its port,
# decremented when it exits (normally or on exception).
# Guarded only by the GIL — int inc/dec is atomic in CPython.
_scan_alive_count: int = 0
_scan_last_restart_ts: float = 0.0
_SCAN_RESTART_INTERVAL: float = 5.0   # seconds between auto-restart attempts

# Most-recently-received MIDI event from any scan port — shown in the UI.
# Written by MIDI threads, read on main thread (GIL-safe for simple assignment).
scan_last_rx: dict = {}   # {"type": "NOTE_ON"/"CC", "ch": int, "num": int, "val": int, "ts": float}


def _learn_scan_loop(port_name, gen):
    """
    Lightweight thread: feed CC / Note On into the learn capture functions.

    WHY sys.modules lookup instead of cached imports
    -------------------------------------------------
    Caching `from .ops_mapping import ingest_midi_for_mapping` at thread-start
    binds to the function object in the module that existed when the thread
    launched.  After a Blender addon reload, Python replaces those module
    objects in sys.modules with fresh ones — new DEV_MAP / DEV_PAD_LEARN /
    DEV_TP instances.  Operators arm the NEW objects; cached thread functions
    still point to the OLD objects.  DEV_PAD_LEARN.learning is True on the new
    object, False on the old one → capture never fires.

    Doing a dict lookup through sys.modules on every message costs one dict
    get() call — negligible — but guarantees we always write to the same object
    that the operators and timer are reading.
    """
    global _scan_alive_count
    mido = _get_mido()
    if not mido:
        return

    import sys as _sys

    _scan_alive_count += 1
    try:
        with mido.open_input(port_name) as inport:
            print(f"[ScoreSync] LearnScan opened: {port_name}")
            # Non-blocking poll so gen check fires every 20 ms even with no MIDI.
            # The old blocking `for msg in inport:` pattern left stale threads alive
            # forever when FL Studio held exclusive WinMM access — they never got a
            # message, never checked gen, and their port handle blocked new threads.
            while gen == _LEARN_SCAN_GEN:
                msg = inport.receive(block=False)
                if msg is None:
                    time.sleep(0.02)
                    continue

                # Fresh module lookup — survives addon reloads
                _m_map  = _sys.modules.get(f"{_PKG}.ops_mapping")
                _m_fx   = _sys.modules.get(f"{_PKG}.ops_fx")
                _m_samp = _sys.modules.get(f"{_PKG}.ops_sampler")
                _m_tp   = _sys.modules.get(f"{_PKG}.ops_transport")

                try:
                    if msg.type == "control_change":
                        scan_last_rx["type"] = "CC"
                        scan_last_rx["ch"]   = msg.channel
                        scan_last_rx["num"]  = msg.control
                        scan_last_rx["val"]  = msg.value
                        scan_last_rx["ts"]   = time.time()
                        scan_last_rx["port"] = port_name
                        if _m_map:
                            try: _m_map.ingest_midi_for_mapping("CC", msg.channel, msg.control, msg.value)
                            except Exception: pass
                            try: _m_map.ingest_midi_for_bank_switch("CC", msg.channel, msg.control, msg.value)
                            except Exception: pass
                        if _m_fx:
                            try: _m_fx.capture_fx_learn("CC", msg.channel, msg.control)
                            except Exception: pass
                        if _m_tp:
                            try: _m_tp.transport_learn_capture("CC", msg.channel, msg.control, msg.value)
                            except Exception: pass

                    elif msg.type == "note_on" and msg.velocity > 0:
                        scan_last_rx["type"] = "NOTE"
                        scan_last_rx["ch"]   = msg.channel
                        scan_last_rx["num"]  = msg.note
                        scan_last_rx["val"]  = msg.velocity
                        scan_last_rx["ts"]   = time.time()
                        scan_last_rx["port"] = port_name
                        print(f"[ScoreSync] LearnScan NOTE_ON ch{msg.channel+1} note{msg.note} vel{msg.velocity} port={port_name}")
                        if _m_map:
                            try: _m_map.ingest_midi_for_mapping("NOTE_ON", msg.channel, msg.note, msg.velocity)
                            except Exception: pass
                            try: _m_map.ingest_midi_for_bank_switch("NOTE_ON", msg.channel, msg.note, msg.velocity)
                            except Exception: pass
                        if _m_fx:
                            try: _m_fx.capture_fx_learn("NOTE_ON", msg.channel, msg.note)
                            except Exception: pass
                        if _m_samp:
                            try: _m_samp.sampler_pad_learn_capture("NOTE_ON", msg.channel, msg.note, msg.velocity)
                            except Exception: pass
                        if _m_tp:
                            try: _m_tp.transport_learn_capture("NOTE_ON", msg.channel, msg.note, msg.velocity)
                            except Exception: pass
                        # Queue for sampler pad fire on main thread
                        _scan_note_queue.append((msg.channel, msg.note, msg.velocity))
                        if _m_fx:
                            try: _m_fx.handle_note_on_fx(msg.channel, msg.note, msg.velocity)
                            except Exception: pass

                    elif msg.type in ("note_off",) or (msg.type == "note_on" and msg.velocity == 0):
                        if _m_map:
                            try: _m_map.ingest_midi_for_mapping("NOTE_OFF", msg.channel, msg.note, 0)
                            except Exception: pass
                            try: _m_map.ingest_midi_for_mapping("NOTE_ON", msg.channel, msg.note, 0)
                            except Exception: pass
                        if _m_fx:
                            try: _m_fx.handle_note_off_fx(msg.channel, msg.note)
                            except Exception: pass

                    elif msg.type == "pitchwheel":
                        norm = int((msg.pitch + 8192) * 127 // 16383)
                        scan_last_rx["type"] = "PITCHBEND"
                        scan_last_rx["ch"]   = msg.channel
                        scan_last_rx["num"]  = 0
                        scan_last_rx["val"]  = norm
                        scan_last_rx["ts"]   = time.time()
                        scan_last_rx["port"] = port_name
                        if _m_map:
                            try: _m_map.ingest_midi_for_mapping("PITCH_BEND", msg.channel, 0, norm)
                            except Exception: pass

                    elif msg.type == "aftertouch":
                        scan_last_rx["type"] = "AFTERTOUCH"
                        scan_last_rx["ch"]   = msg.channel
                        scan_last_rx["num"]  = 0
                        scan_last_rx["val"]  = msg.value
                        scan_last_rx["ts"]   = time.time()
                        scan_last_rx["port"] = port_name
                        if _m_map:
                            try: _m_map.ingest_midi_for_mapping("AFTERTOUCH", msg.channel, 0, msg.value)
                            except Exception: pass

                    elif msg.type == "polytouch":
                        scan_last_rx["type"] = "POLY_AT"
                        scan_last_rx["ch"]   = msg.channel
                        scan_last_rx["num"]  = msg.note
                        scan_last_rx["val"]  = msg.value
                        scan_last_rx["ts"]   = time.time()
                        scan_last_rx["port"] = port_name
                        if _m_map:
                            try: _m_map.ingest_midi_for_mapping("POLY_AT", msg.channel, msg.note, msg.value)
                            except Exception: pass

                    elif msg.type == "program_change":
                        scan_last_rx["type"] = "PROG_CHG"
                        scan_last_rx["ch"]   = msg.channel
                        scan_last_rx["num"]  = msg.program
                        scan_last_rx["val"]  = msg.program
                        scan_last_rx["ts"]   = time.time()
                        scan_last_rx["port"] = port_name
                        if _m_map:
                            try: _m_map.ingest_midi_for_mapping("PROG_CHG", msg.channel, msg.program, msg.program)
                            except Exception: pass
                        if _m_tp:
                            try: _m_tp.transport_learn_capture("PROG_CHG", msg.channel, msg.program, msg.program)
                            except Exception: pass

                except Exception:
                    pass
            print(f"[ScoreSync] LearnScan closed: {port_name}")
    except Exception as e:
        print(f"[ScoreSync] LearnScan disconnected ({port_name}): {e}")
    finally:
        _scan_alive_count -= 1
        print(f"[ScoreSync] LearnScan thread exited: {port_name}  (alive={_scan_alive_count})")


def start_learn_scan():
    """Open temporary listeners on all MIDI inputs not already used by the main listener."""
    global _LEARN_SCAN_GEN, _learn_scan_threads

    mido = _get_mido()
    if not mido:
        print("[ScoreSync] LearnScan: mido not available")
        return

    try:
        all_ports = mido.get_input_names()
    except Exception as e:
        print(f"[ScoreSync] LearnScan: cannot enumerate ports — {e}")
        return

    # Bump generation — existing threads will exit on their next message
    _LEARN_SCAN_GEN += 1
    gen = _LEARN_SCAN_GEN

    # Ports already open by the main/health listener — skip to avoid WinMM conflict
    skip = set()
    if DEV.in_port_name:
        skip.add(DEV.in_port_name)
    if DEV.health_port_name:
        skip.add(DEV.health_port_name)

    _learn_scan_threads = []
    skipped = []

    for name in all_ports:
        if name in skip:
            skipped.append(name)
            continue
        t = threading.Thread(target=_learn_scan_loop, args=(name, gen), daemon=True)
        t.start()
        _learn_scan_threads.append(t)

    print(f"[ScoreSync] LearnScan gen={gen} | scanning {len(_learn_scan_threads)} port(s): "
          f"{[t.name for t in _learn_scan_threads]}")
    if skipped:
        print(f"[ScoreSync] LearnScan skipped (already open): {skipped}")
    if not _learn_scan_threads and not skipped:
        print("[ScoreSync] LearnScan: no MIDI input ports found — plug in controller and retry")


def stop_learn_scan():
    """Retire the current scan generation; threads exit on their next message."""
    global _LEARN_SCAN_GEN, _learn_scan_threads
    _LEARN_SCAN_GEN += 1   # invalidate all running scan threads
    _learn_scan_threads = []
    print(f"[ScoreSync] LearnScan stopped (gen now {_LEARN_SCAN_GEN})")
    _learn_scan_threads = []
    print("[ScoreSync] LearnScan stopped")


# ---- Operators --------------------------------------------------------------
class SCORESYNC_OT_refresh_ports(bpy.types.Operator):
    bl_idname = "scoresync.refresh_ports"
    bl_label = "Refresh MIDI Ports"
    def execute(self, context):
        for area in context.screen.areas:
            area.tag_redraw()
        self.report({'INFO'}, "Ports refreshed")
        return {'FINISHED'}

class SCORESYNC_OT_connect(bpy.types.Operator):
    bl_idname = "scoresync.connect"
    bl_label = "(Re)Connect MIDI"
    _thread = None
    def execute(self, context):
        scene = context.scene
        mido = _get_mido()
        if not mido:
            scene.scoresync_status = "Deps missing (Install MIDI Dependencies)"
            self.report({'WARNING'}, "Install dependencies first (mido + python-rtmidi)")
            return {'CANCELLED'}

        in_name = getattr(scene, "scoresync_input_port", "NONE")
        out_name = getattr(scene, "scoresync_output_port", "NONE")

        # Close previous out
        try:
            if DEV.out_port:
                DEV.out_port.close()
        except Exception:
            pass
        DEV.out_port = None
        DEV.out_port_name = None

        # Open output
        if out_name and out_name != "NONE":
            try:
                DEV.out_port = mido.open_output(out_name)
                DEV.out_port_name = out_name
                print("[ScoreSync] MIDI Out opened:", out_name)
                # Start a second input listener on the OUT port name (for FL ACK)
                try:
                    inputs = set(mido.get_input_names())
                except Exception:
                    inputs = set()
                DEV.health_stop_requested = True
                try:
                    if DEV.health_in_port:
                        DEV.health_in_port.close()
                except Exception:
                    pass
                DEV.health_in_port = None
                DEV.health_stop_requested = False


                # If the OUT port name exists as an input too (loopMIDI does this),
                # listen there for CC119=100 so Blender can show "FL Script OK".
                if out_name in inputs and (not DEV.health_listener_running):
                    DEV.health_stop_requested = True
                    try:
                        if DEV.health_in_port:
                            DEV.health_in_port.close()
                    except Exception:
                        pass
                    time.sleep(0.02)
                    DEV.health_stop_requested = False
                    DEV.health_port_name = out_name
                    threading.Thread(
                        target=_health_listener_loop,
                        args=(out_name,),
                        daemon=True
                    ).start()

                # show immediate confirmation in the ui
                scene.scoresync_status = f"Out opened: {out_name} (pick MIDI In to follow DAW)"

            except Exception as e:
                DEV.out_port = None
                scene.scoresync_status = f"Error: failed to open MIDI Out '{out_name}': {e}"
                



        # Start input listener
        DEV.in_port_name = None
        if in_name and in_name != "NONE":
            DEV.in_port_name = in_name
            # stop any previous listener cleanly
            DEV.stop_requested = True
            try:
                if DEV.in_port:
                    DEV.in_port.close()
            except Exception:
                pass
            time.sleep(0.05)
            DEV.stop_requested = False

            DEV.frame_origin = int(scene.frame_current)
            DEV.frame_accum_f = 0.0
            DEV.clock_total = 0
            DEV.clocks_in_bar = 0
            DEV.bar_index = 1
            try:
                from .ops_mapping import DEV_MAP
                DEV_MAP.last_val.clear()
                DEV_MAP.prev_raw.clear()
                DEV_MAP.toggle_state.clear()
                DEV_MAP.encoder_accum.clear()
                try:
                    from .ops_transport import DEV_TP
                    DEV_TP.prev_raw.clear()
                except Exception:
                    pass
            except Exception:
                pass
            _scan_note_queue.clear()
            global _LISTENER_GEN
            _LISTENER_GEN += 1
            gen = _LISTENER_GEN

            self._thread = threading.Thread(
                target=_listener_loop,
                args=(in_name, gen),
                daemon=True
            )
            self._thread.start()
            scene.scoresync_status = f"In: {in_name} | Out: {DEV.out_port_name or 'none'}"

        else:
            scene.scoresync_status = f"In: {in_name} | Out: {DEV.out_port_name or 'none'}"
            self.report({'WARNING'}, "Pick a MIDI In for DAW → Blender listening")

        # Persist port names so they can be restored next session
        try:
            from .prefs import save_last_ports
            save_last_ports(in_name, DEV.out_port_name or "")
        except Exception:
            pass

        # Ensure timer
        if not DEV.timer_registered:
            try:
                bpy.app.timers.register(scoresync_timer, first_interval=0.2)
                DEV.timer_registered = True
            except Exception:
                pass

        # Start permanent universal scanner — listens to all non-F2B ports
        # so any USB controller delivers live values to mappings/FX at all times
        start_learn_scan()

        return {'FINISHED'}

class SCORESYNC_OT_reconnect_now(bpy.types.Operator):
    bl_idname = "scoresync.reconnect_now"
    bl_label = "Reconnect now"
    def execute(self, context):
        try:
            if DEV.out_port:
                DEV.out_port.close()
        except Exception:
            pass
        DEV.out_port = None
        DEV.health_stop_requested = True
        try:
            if DEV.health_in_port:
                DEV.health_in_port.close()
        except Exception:
            pass
        DEV.health_in_port = None
        DEV.listener_running = False
        self.report({'INFO'}, "Reconnecting…")
        bpy.ops.scoresync.connect()
        return {'FINISHED'}


class SCORESYNC_OT_reset_scan(bpy.types.Operator):
    """Force-restart the MIDI controller scan — use this if your controller
    was unplugged and auto-reconnect hasn't fired yet, or after a USB reset"""
    bl_idname = "scoresync.reset_scan"
    bl_label  = "Reset Controller Scan"

    def execute(self, context):
        global _scan_last_restart_ts
        _scan_last_restart_ts = 0.0   # reset cooldown so _ensure_ports can fire immediately
        try:
            start_learn_scan()
        except Exception as e:
            self.report({'WARNING'}, f"Scan restart failed: {e}")
            return {'CANCELLED'}
        alive = _scan_alive_count
        self.report({'INFO'}, f"Controller scan restarted ({alive} port(s) opening…)")
        return {'FINISHED'}
